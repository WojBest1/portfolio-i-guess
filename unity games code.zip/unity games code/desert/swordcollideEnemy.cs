using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class swordcollideEnemy : MonoBehaviour
{
    public bool hit;
    void OnTriggerEnter(Collider other)
    {

        if (other.gameObject.tag == "Player")
        {


            hit = true;

        }




    }
    void OnTriggerExit(Collider other)
    {

        hit = false;
    }
}
