using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class enemyhealth : MonoBehaviour
{
    [SerializeField] swordcollide sw;
    [SerializeField] animations am;
    public Slider healthSlider;
    public float maxhp = 20f;
    public float health;
    float timer;
    bool startTime;
    bool once;

    void Start()
    {
        health = maxhp;
    
    }

    void Update()
    {



        if (healthSlider.value != health)
        {
            healthSlider.value = health;
        }





        if (Input.GetKeyDown(KeyCode.Mouse0) && am.hasword)
        {
            startTime = true;
            if (timer == 0)
            {
                once = false;
            }
        }
   

        if (startTime == true)
        {
            timer += Time.deltaTime;
        }

        if (timer < 1.5)
        {

            if (sw.hit == true && once == false && am.attackTimer > 1)
            {
                once = true;
                takeDamage(5);
            }
        }

        if (timer > 1.5)
        {
            timer = 0;
        startTime = false;

        }




    }
    
    public void takeDamage(float damage)
    {

        health -= damage;
    }
}
