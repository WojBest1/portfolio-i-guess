using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class destroy : MonoBehaviour
{
 

    public void Destroy()
    {
        Destroy(gameObject);
    }
}
