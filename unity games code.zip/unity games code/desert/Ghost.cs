using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UIElements;

public class Ghost : MonoBehaviour
{
    public LayerMask wall;
    public LayerMask WP;

    public Transform backleft;
    bool chase = false;
    bool oneDirection;
    public Transform empty;
    Quaternion targetRotation; 
    public Transform looker,looker2;
    string lastHitObjectName = "";
    public Transform wp1, wp2, enemy;
    public Transform playerHitbox;
    int place = 0;
    int listp = 0;
    int up = 1;
    bool foundsmthn = false;
    bool s;
    List<Transform> spawnedObjectTransforms = new List<Transform>();
    List<Transform> actual = new List<Transform>();
    int last = 0;
    int last1 = 0;
    bool once = false;
    bool playerPlace =false;
    int f = 0;
    int a = 0;
    bool seePlayer = false;
    int downlist = 1;
    bool optimalRoute;
    bool somthing;
    int listp1= 0;
    bool i = false;
    bool seenonce = false;
    bool countStored = false;

    private void Start()
    {

        workwithit();
    }

    void Update()
    {
        bool notLots = Physics.CheckSphere(backleft.position, 2.5f, WP);

        if (notLots == false && enemy.gameObject.active==true)
        {
            Instantiate(wp1, backleft.position, Quaternion.identity);
            Transform newObject = Instantiate(wp1, backleft.position, Quaternion.identity);
    

            spawnedObjectTransforms.Add(newObject.transform);
        }

        if (spawnedObjectTransforms.Count > up)
        {
            s = Physics.Linecast(spawnedObjectTransforms[listp].position, spawnedObjectTransforms[up].position, out RaycastHit hit3);
            if (!s)
            {
                foundsmthn = false;
            }

            last = listp;
            if (s)
            {

                foundsmthn = false;


                if (hit3.collider.gameObject.layer == 7)
                {
            
                
                    listp = up;

                    foundsmthn = true;
    
                    up+=2;

      
                }


            }
            if (last != listp || once == false)
            {
                last = listp;
              

                if (once == false)
                {
                    actual.Add(spawnedObjectTransforms[0]);
                    f = 0;
                }
                if (once == true)
                {
                    f=1;
                    actual.Add(spawnedObjectTransforms[up - 4]);
                }
                if (f == 0)
                {
                    Instantiate(wp2, spawnedObjectTransforms[0].position, Quaternion.identity);
                }
                if (f == 1)
                {
                   Instantiate(wp2, spawnedObjectTransforms[up - 4].position, Quaternion.identity);
                }
                f = 0;
            }
            if (foundsmthn == false)
            {     
                up++;
            }
            once = true;
            
        }

        RaycastHit hit1;
        if (Physics.Raycast(enemy.position, enemy.forward, out hit1, 2f, wall))
        {
            GameObject hitObject = hit1.collider.gameObject;
            string hitObjectName = hitObject.name;

            // Check if the current hit object's name is different from the last hit object's name
            if (hitObjectName != lastHitObjectName)
            {

                oneDirection = false;
                workwithit();
            }

 
            lastHitObjectName = hitObjectName;
        }



        bool notLots2 = Physics.CheckSphere(empty.position, 2, WP);


        bool raycastResult = Physics.Raycast(looker.position, looker.forward, out RaycastHit hit, 100);
        looker2.LookAt(playerHitbox);
        LayerMask layerMask = ~LayerMask.GetMask("WP");

     
        bool raycastResult2 = Physics.Raycast(looker2.position, looker2.forward, out RaycastHit hit2, 220, layerMask);
        if (raycastResult)
        {
            if (hit.collider.tag == "Player" && spawnedObjectTransforms.Count < up)
            {

                
                downlist = actual.Count;
                enemy.gameObject.SetActive(false);

                playerPlace = true;
            }
            else
            {
                chase = false;
            }
      
        }
        if (raycastResult2)
        {



            if (hit2.collider.tag == "Player")
            {
                Debug.Log("seeplayer");
                transform.position = Vector3.MoveTowards(transform.position, empty.position, 0.03f);
          seePlayer = true;
                seenonce = true;
            }


            if (hit2.collider.tag != "Player" && seenonce)
            {
                seePlayer = false;
            }

        }


        if (seePlayer == false && seenonce == true && countStored == false)
        {
 
           
            countStored = true; 
        }

        if (seePlayer == false && seenonce == true && i == false)
        {
            RaycastHit hit4;
            if (actual.Count > downlist)
            {
                optimalRoute = Physics.Linecast(transform.position, actual[downlist].position, out hit4);


                if (hit4.collider != null && hit4.collider.gameObject.name == "WP 2(Clone)")
                {
                    optimalRoute = false;
                }

         
                last1 = listp1;
                if (hit4.collider != null && hit4.collider.gameObject.layer == 7)
                {

                    listp1 = downlist;

                    somthing = true;

                    downlist -= 1;


                }
                if (!optimalRoute)
                {
                    somthing = false;
                }
                if (last1 != listp1)
                {
                    last1 = listp1;




                    actual.Add(actual[downlist]);
                    Instantiate(wp2, actual[downlist].position, Quaternion.identity);
                    f = 0;
                    i = true;
                }

                if (somthing == false)
                {

                    downlist++;
                }

            }

        }
        if (i == true)
        {
          

            transform.position = Vector3.MoveTowards(transform.position, actual[downlist].position, 0.03f);
         
            float positionThreshold = 1f; 

            if (Vector3.Distance(transform.position, actual[downlist].position) < positionThreshold)
            {
                i = false;
                foreach (Transform t in actual)
                {
                    Destroy(t.gameObject);
                }
                actual.Clear();
            }

        }

        if (notLots2 == false && playerPlace == true)
        {


            Transform newObj = Instantiate(wp2, empty.position, Quaternion.identity);

            actual.Add(newObj);


        }
        if (actual.Count > 1 && seePlayer==false && i == false)
        {


            if (a < actual.Count)
            {
                    transform.position = Vector3.MoveTowards(transform.position, actual[a].position, 0.03f);
                    if (transform.position == actual[a].position)
                    {
                        a++;
                    }
  
            }
              
            
           
        }

        if (chase == true)
        {

            enemy.position = Vector3.MoveTowards(enemy.position, empty.position, 0.03f);

        }

        if (chase == false)
        {
            bool wallcheck = Physics.CheckSphere(enemy.position, 4, wall);

            if (wallcheck)
            {

                workwithit();
                oneDirection = true;
            }
            else if (!wallcheck)
            {
                oneDirection = false;
                workwithit();
            }
            if (Input.GetKey(KeyCode.Space))
            {
                workwithit();
            }
           enemy.Translate(Vector3.forward *20 * Time.deltaTime);
            enemy.rotation = targetRotation;

        }


    }


















    private void workwithit()
    {
        bool raycastForward = Physics.Raycast(enemy.position, enemy.forward, 4f, wall);
        bool raycastRight = Physics.Raycast(enemy.position, enemy.right, 4f, wall);
        bool raycastback = Physics.Raycast(enemy.position, -enemy.forward, 4f, wall);
        bool raycastleft = Physics.Raycast(enemy.position, -enemy.right, 4f, wall);


        float distanceForward = 0f;
        float distanceRight = 0f;
        float distanceBackwards = 0f;
        float distanceLeft = 0f;
        List<float> available = new List<float>();

        if (raycastForward == false)
        {
            Vector3 forward = enemy.position + enemy.forward * 2f;
            distanceForward = Vector3.Distance(forward, empty.position);
            available.Add(distanceForward);
        }
        if (raycastRight == false)
        {

            Vector3 right = enemy.position + enemy.right * 2f;
            distanceRight = Vector3.Distance(right, empty.position);
            available.Add(distanceRight);
        }
        if (raycastback == false)
        {
            Vector3 backwards = enemy.position - enemy.forward * 2f;
            distanceBackwards = Vector3.Distance(backwards, empty.position);
            available.Add(distanceBackwards);
        }
        if (raycastleft == false)
        {
            Vector3 left = enemy.position - enemy.right * 2f;
            distanceLeft = Vector3.Distance(left, empty.position);
            available.Add(distanceLeft);
        }


        available.Sort();
        place = 0;


        if (available[place] == distanceRight && oneDirection == false)
        {




            Quaternion currentRotation = enemy.rotation;
            Quaternion newRotation = Quaternion.Euler(0f, currentRotation.eulerAngles.y + 90f, 0f);
            targetRotation = newRotation;
            // Debug.Log("right");
        }
        if (available[place] == distanceForward && oneDirection == false)
        {
            //Debug.Log("forward");


        }
        if (available[place] == distanceLeft && oneDirection == false)
        {
            //   Debug.Log("left");
            Quaternion currentRotation = enemy.rotation;
            Quaternion newRotation = Quaternion.Euler(0f, currentRotation.eulerAngles.y - 90f, 0f);
            targetRotation = newRotation;
        }


        if (available[place] == distanceBackwards && oneDirection == false)
        {

            targetRotation = Quaternion.Euler(0f, 180f, 0f);
        }






        available.Clear();
    }
}