using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Grappler : MonoBehaviour
{
    public LineRenderer lr;
    public Transform cam;
    public Rigidbody rb;
    public Transform Guntip;
    RaycastHit hit;
    public LayerMask lm;
    public float MaximumRAY = 100f;
    bool grapple = false;
    bool grapple1 = true;
    PlayerMovement pr;
    public float maxGrappleDistance;
    public float grappleDelayTime;
    public float overshootYAxis;
    public Transform player;
    bool ray;
    float currentTime =10f;
    bool startCount;
    public Image fillImage;
    private void Start()
    {
  
        rb = GetComponent<Rigidbody>();
        pr = GetComponent<PlayerMovement>();
    }
     void Update()
     {
     
        if (currentTime <= 0)
        {
            currentTime = 10f;
            startCount = false;
            grapple = false;

        }
        if (currentTime < 10f)
        {
            grapple = true;
            fillImage.fillAmount = currentTime / 10f;

        }

      
        if (startCount == true)
        {
            currentTime -= 1 * Time.deltaTime;
        }

        if (grapple1 == true)
        {
            ray = Physics.Raycast(transform.position, cam.forward, out hit, MaximumRAY, lm);

        }
        if (ray && Input.GetKey(KeyCode.Q) )
        {
            if (grapple == false)
            {

                ExecuteGrapple();

                grapple1 = false;

                lr.enabled = true;



                startCount = true;
            }
            Vector3 vector3 = new Vector3(transform.position.x - 0.39f, transform.position.y + 0.2f, transform.position.z + 0.871f);
            lr.SetPosition(0, vector3); 
        }
        else
        {
           
            grapple1 = true;
       lr.enabled = false;
            pr.moveSpeed = 7;
            rb.isKinematic = false;
        }
      
     
    }
    private void ExecuteGrapple()
    {


        lr.SetPosition(1, hit.point);
        Vector3 grapplePoint = hit.point;
        Vector3 lowestPoint = new Vector3(transform.position.x, transform.position.y - 1f, transform.position.z);

        float grapplePointRelativeYPos = grapplePoint.y - lowestPoint.y;
        float highestPointOnArc = grapplePointRelativeYPos + overshootYAxis;

        if (grapplePointRelativeYPos < 0) highestPointOnArc = overshootYAxis;
        pr.moveSpeed = 0;
        JumpToPosition(grapplePoint, highestPointOnArc);


    }
    public void JumpToPosition(Vector3 targetPosition, float trajectoryHeight)
    {
        rb.velocity = CalculateJumpVelocity(transform.position, targetPosition, trajectoryHeight);
        pr.moveSpeed = 0;
        player.transform.position = Vector3.MoveTowards(player.transform.position, hit.point, 3f);
    }
    



    public Vector3 CalculateJumpVelocity(Vector3 startPoint, Vector3 endPoint, float trajectoryHeight)
    {
        float gravity = Physics.gravity.y;
        float displacementY = endPoint.y - startPoint.y;
        Vector3 displacementXZ = new Vector3(endPoint.x - startPoint.x, 0f, endPoint.z - startPoint.z);

        Vector3 velocityY = Vector3.up * Mathf.Sqrt(-2 * gravity * trajectoryHeight);
        Vector3 velocityXZ = displacementXZ / (Mathf.Sqrt(-2 * trajectoryHeight / gravity)
            + Mathf.Sqrt(2 * (displacementY - trajectoryHeight) / gravity));

        pr.moveSpeed = 0;
        return velocityXZ + velocityY;
    }





}
