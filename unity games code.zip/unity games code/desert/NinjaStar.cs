using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;
public class NinjaStar : MonoBehaviour
{
    public Text amount;
    public Transform[] ninjaStar = new Transform[3];

    public Transform ShooFrom;
    int up = -1;
    private float targetDuration1 = 5f;
    public Transform playercam;
    float ninjastar = 0.15f;
    private float timeCalc = 0f;
    private float calc;
    public int amountI =3;
    public Image fillImage;
    bool full;
  public  float shootcooldown;
  public bool timer;
    public bool xc = true;
    Vector3 camfor;
    private void Start()
    {
        ninjaStar[0].gameObject.SetActive(false);
        ninjaStar[1].gameObject.SetActive(false); 
        ninjaStar[2].gameObject.SetActive(false);
        ninjaStar[0].position = ShooFrom.position;
        ninjaStar[1].position = ShooFrom.position;
        ninjaStar[2].position = ShooFrom.position;
    }
    void Update()
    {
      
            Ninjastar();
        
    }
    private void Ninjastar()
    {


    

        if (up >= 0)
        {
        
           
            ninjaStar[0].gameObject.SetActive(true);
            ninjaStar[0].Translate(camfor * ninjastar, Space.World);
            ninjaStar[0].SetParent(null);
            full = false;
        }


        if (up >= 1)
        {
        
            ninjaStar[1].gameObject.SetActive(true);
            ninjaStar[1].Translate(camfor * ninjastar, Space.World);
            ninjaStar[1].SetParent(null);
            full = false;



        }

        if (up >= 2)
        {
     
            ninjaStar[2].gameObject.SetActive(true);
            ninjaStar[2].Translate(camfor * ninjastar, Space.World);
            ninjaStar[2].SetParent(null);
            full = false;
      
        }
       
        if (full == false)
        {
            timeCalc += Time.deltaTime;


            calc = timeCalc / targetDuration1;


            fillImage.fillAmount = calc;
        }


   
     
        if (timeCalc > targetDuration1)
        {
            if (up < 3 && up >= 0)
            {


   
                if (up < 3 && up >= 0)
                {
                    ninjaStar[up].position = ShooFrom.position;
                    ninjaStar[up].gameObject.SetActive(false);
                    ninjaStar[up].SetParent(playercam);
              
                }
                amountI++;
                up--;
           
            }
            calc = 0;
            timeCalc = 0;
            if (amountI == 3)
            {

                full = true;
            }
 

            if (amountI == 3&& full ==true)
            {

              
                fillImage.fillAmount = 1f;
            }
        }

      
        if (Input.GetKeyDown(KeyCode.Mouse1))
        {
            camfor = playercam.forward;
        if (up < 2 && amountI > 0) 
        {

                timer = true;
              
              
                    up++;
                    amountI--;


            
        }
    }
        if (Input.GetKeyUp(KeyCode.Mouse1))
        {
            timer = false;

        }

            amount.text = amountI.ToString();






    }
}
