using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.UI;
using System;
public class HealthManager : MonoBehaviour
{
    private float targetDuration = 5f; 
    private float timeCalc = 0f;

    private bool KeepFilling = true;
    public Image fillImage;



    void Start()
    {
        PlayerMovement playerMovement = GetComponent<PlayerMovement>();
        playerMovement.OnDoubleJump += PlayerMovement_OnDoubleJump;
    }

    private void PlayerMovement_OnDoubleJump(object sender, EventArgs e)
    {
        KeepFilling = true;
        timeCalc = 0;
       
        fillImage.fillAmount = 0;

    }

   
    void Update()
    {



        if (KeepFilling ==true)
        {
           
            timeCalc += Time.deltaTime;

        
            fillImage.fillAmount = timeCalc / targetDuration;

       
            if (timeCalc >= targetDuration)
            {
                KeepFilling = false; 
            }
        }
     
    }
}

