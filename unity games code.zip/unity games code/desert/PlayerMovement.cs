using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using TMPro;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;




public class PlayerMovement : MonoBehaviour
{

   
   
    [SerializeField] PlayerCams playerCams;
    public LayerMask wallrun;
    public event EventHandler OnDoubleJump;
    private float targetDuration = 5f; 
    private float timeCalc = 0f;
    public float moveSpeed;
    public float groundDrag;
    public float jumpForce;
    public float jumpCooldown;
    public float airMultiplier;
     bool jumpOnce;
    bool readyToJump;
    public KeyCode jumpKey = KeyCode.Space;
    Vector3 RotateMax;
    Vector3 eulerRotation;
    public float playerHeight;
    public LayerMask whatisGround;
    bool grounded;
    public Transform orientation;
    float horizontalInput;
    float VerticalInput;
    public Vector3 moveDirection;
    public float rotationSpeed = 50f;
    public Rigidbody rb;
    bool wallrun1;
    bool wallrun11;
    bool wallrun111;
    public float maxSlopeAngle;
  public bool freeze;
      bool activeGrapple;
    Vector3 scalexz;
   float scaley;
    public Transform player;
    public Transform left;
    PlayerCams pc;
    public bool sprt;
    bool WR =false;
    bool checkwall;


    private void Start()
    {
        pc = GetComponent<PlayerCams>();

        readyToJump = true;
        rb = GetComponent<Rigidbody>();
      
    }

    private void Update()
    {

        grounded = Physics.Raycast(transform.position, Vector3.down, playerHeight * 0.5f + 0.2f, whatisGround);




        timeCalc += Time.deltaTime;



  


        if (timeCalc >= targetDuration)
            {

            if (readyToJump && Input.GetKeyDown(KeyCode.Space) && jumpOnce == false && grounded == false)
            {

                if (jumpOnce == false)
                {


                    rb.AddForce(transform.up * jumpForce * 3f, ForceMode.Impulse);

                    jumpOnce = true;

                    if (OnDoubleJump != null)
                    {
                        OnDoubleJump(this, EventArgs.Empty);
                    }

                }

            }
        }
        if (jumpOnce == true)
        {

            timeCalc = 0f;

            jumpOnce = false;

        }

        if (grounded && !activeGrapple)
            rb.drag = groundDrag;
        else
            rb.drag = 0;


  
        if (grounded)
        {
            rb.drag = groundDrag;


        }
        else
            rb.drag = 0;

        MyInput();

        Wallrun();
        sprint();
        if (moveSpeed == 7)
        {
            sprt = true;
        }
        if (moveSpeed == 4)
        {

            sprt  = false;
        }
    }


    private void Wallrun()
    {
        
        wallrun11 = Physics.Raycast(player.position, player.right, 16, wallrun);

        checkwall = Physics.CheckSphere(player.position, 4, wallrun);
      
        wallrun1 = Physics.Raycast(player.position, player.forward,  3, wallrun);
  
           if(Input.GetKey(KeyCode.Space) && wallrun1)
           {

           WR = true;


           }


        if (Input.GetKeyUp(KeyCode.Space) || checkwall ==false)
        {
           

                WR = false;
                playerCams.roate = false;
                playerCams.rotateRight = false;
                playerCams.rotateLeft = false;
       
            
        }
  
        if (WR == true )
        {

          
            scalexz = new Vector3(15f, 0f, 15f);
            scaley = 7f;

            if (wallrun11 == true)
            {
                playerCams.rotateRight = false;
                playerCams.rotateLeft = true;
                playerCams.roate = true;
            }
            if (wallrun11 == false)
            {
                playerCams.rotateLeft = false;
                playerCams.rotateRight = true;
                playerCams.roate = true;
            }



            rb.velocity = CalculateJumpVelocity(scalexz.normalized, scaley);

        }




    }


        public Vector3 CalculateJumpVelocity(Vector3 scalexz, float scaley)
     {
    



        float calc = scaley * scaley;
         Vector3 cacl1 = new Vector3(scalexz.x * scalexz.x, calc, scalexz.z * scalexz.z);
     

        float scaleX = cacl1.x;
        float scaleY = cacl1.y;
        float scaleZ = cacl1.z;

        double sqrt_scalexzX = Math.Sqrt(scaleX);
        double sqrt_scalexzY = Math.Sqrt(scaleY);       
        double sqrt_scalexzZ = Math.Sqrt(scaleZ);


        Vector3 calc3 = new Vector3((float)sqrt_scalexzX , (float)sqrt_scalexzY, (float)sqrt_scalexzZ);
   
        Vector3 adjustedCalc3 = calc3 ;
  
        return adjustedCalc3;

        }




 

    private void sprint()
    {

        if (Input.GetKey(KeyCode.LeftShift))
        {

            moveSpeed = 7;



        }
        else if (Input.GetKeyUp(KeyCode.LeftShift))
        {

            moveSpeed = 4;
        }





    }
    private void FixedUpdate()
    {
        MovePlayer();
    }
   

    private void MyInput()
    {
        horizontalInput = Input.GetAxisRaw("Horizontal");
        VerticalInput = Input.GetAxisRaw("Vertical");

        

        if (Input.GetKey(jumpKey) && readyToJump && grounded)
        {

            readyToJump = false;
            jump();

            Invoke(nameof(ResetJump), jumpCooldown);
        }

    }



    private void MovePlayer()
    {
        if (activeGrapple) return;
         moveDirection = (orientation.forward * VerticalInput + orientation.right * horizontalInput).normalized;
            
        if (grounded)
        {
   
            transform.Translate(moveDirection * 100f * Time.fixedDeltaTime, Space.World);

        }
        else
        {
            
            transform.Translate(moveDirection * 100f * airMultiplier * Time.fixedDeltaTime, Space.World);
      
        }
     
    }


    private void jump()
    {
        rb.velocity = new Vector3(rb.velocity.x, 0f, rb.velocity.z);

        rb.AddForce(transform.up * jumpForce, ForceMode.Impulse);
    }
    private void ResetJump()
    {
        readyToJump = true;
    }


}
