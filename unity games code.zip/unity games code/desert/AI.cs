using Microsoft.Unity.VisualStudio.Editor;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using Unity.VisualScripting;
using UnityEditor;
using UnityEditor.PackageManager;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;

public class AI : MonoBehaviour
{
    public UnityEngine.UI.Image im;
    [SerializeField] swordcollideEnemy swe;
    private float timer = 0f;
     float spawnDelay11 = 0.3f;
    public GameObject target;
    public GameObject Enemy;
    public GameObject EnemyHead;
    float speed = 0.03f;
    public GameObject waypointPrefab;
    int up = 0;
    bool go = false;
    private List<Transform> Waypoints = new List<Transform>();
    public List<Transform> PatrolWaypoints = new List<Transform>(); 
    public LayerMask whatisGround;
    public LayerMask whatisPlayer;
    public LayerMask waypoint;
    public LayerMask player;
    int Newup = 0;
    public float playerHeight;
    float sighttRange =5f;
    float sighttRange2 = 2f;
    bool patrolling;
    bool chasing;
    bool dontstop;
    public float maxhp = 30f;
    public float health;
    public Animator animator;
    bool stoppatrol;
    float newtimer;
    bool startTime;
    float currenhp  =1;
    bool once = true;
    private void Update()
    {
        bool placeonce = Physics.CheckSphere(target.transform.position, sighttRange2, waypoint);




        bool attack = Physics.Raycast(Enemy.transform.position, Enemy.transform.forward, 1, player);
       bool playerChase = Physics.CheckSphere(Enemy.transform.position, sighttRange, whatisPlayer);

        if (playerChase == true)
        {
            dontstop = true;
        }
        if (dontstop == true)
        {
            stoppatrol = true;
            chasing = true;
            patrolling = false;
          
        }
        if (attack == true)
        {
            
            animator.SetBool("attack", true);
  
            if (newtimer == 0)
            {
                once = false;
            }

            startTime = true;


            if (swe.hit == true && once == false)
            {

                maxhp -= 5;
      
                currenhp -= 0.1666666666666667f;


                im.fillAmount = currenhp;
                once = true;

            }

            chasing = false;
        }



        if (newtimer > 1)
        {
            newtimer = 0;
            startTime = false;
            animator.SetBool("attack", false);
        }



        if (startTime == true)
        {

            newtimer += Time.deltaTime;
        }

        if (attack == false)
        {

            if (stoppatrol == true)
            {
                chasing = true;
            }
        }

        if (chasing == true)
        {
            bool grounded;
            grounded = Physics.Raycast(Enemy.transform.position, Vector3.down, playerHeight * 0.5f + 0.4f, whatisGround);
            timer += Time.deltaTime;

     
            if (timer >= spawnDelay11 && placeonce ==false)
            {

                GameObject waypoint = Instantiate(waypointPrefab, target.transform.position, Quaternion.identity);
                Waypoints.Add(waypoint.transform);
                timer = 0f;

                go = true;
            }

            if (go == true)
            {

                Vector3 direction = target.transform.position - Enemy.transform.position;
                Quaternion rotation = Quaternion.LookRotation(direction);

               
                rotation = Quaternion.Euler(0, rotation.eulerAngles.y, rotation.eulerAngles.z);

                Enemy.transform.rotation = rotation;

                if (up < Waypoints.Count)
                {
                    Enemy.transform.position = Vector3.MoveTowards(Enemy.transform.position, Waypoints[up].position, speed);


                }
            }
            if (go)
            {
                Vector3 direction = target.transform.position - Enemy.transform.position;
                Quaternion rotation = Quaternion.LookRotation(direction);

                rotation = Quaternion.Euler(0, rotation.eulerAngles.y, rotation.eulerAngles.z);
                Enemy.transform.rotation = rotation;

                if (up < Waypoints.Count)
                {
                    Enemy.transform.position = Vector3.MoveTowards(Enemy.transform.position, Waypoints[up].position, speed);

                  
                    if (Vector3.Distance(Enemy.transform.position, Waypoints[up].position) < 0.1f)
                    {
                 
                        Destroy(Waypoints[up].gameObject);
                        Waypoints.RemoveAt(up);
                       
                    }
                }
            }
        }
        if (patrolling == true)
        {
            Enemy.transform.position = Vector3.MoveTowards(Enemy.transform.position, PatrolWaypoints[Newup].position, speed);
            Vector3 direction = PatrolWaypoints[Newup].position - Enemy.transform.position;

    
            if (direction != Vector3.zero)
            {
                Quaternion targetRotation = Quaternion.LookRotation(direction);

                float rotationSpeed = 10f; 
                Enemy.transform.rotation = Quaternion.Lerp(Enemy.transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
            }
            if (Newup < PatrolWaypoints.Count)
            {
                if (PatrolWaypoints[Newup].position == Enemy.transform.position)
                {
                    Newup++;
                }




            }
            if (Newup >= PatrolWaypoints.Count)
            {
                Newup = 0;
            }


        }

  
    } 
}


