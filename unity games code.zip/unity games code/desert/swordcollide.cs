using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class swordcollide : MonoBehaviour
{
    public bool hit;
 


    


    void OnTriggerEnter(Collider other)
    {

          if (other.gameObject.tag == "Enemy")
          {

          
                hit = true;

          }
        



    }
    void OnTriggerExit(Collider other)
    {
     
        hit = false;
    }
}