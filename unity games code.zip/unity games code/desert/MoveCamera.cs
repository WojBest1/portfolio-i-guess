using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveCamera : MonoBehaviour
{
    public Transform cameraPostion;

    public Transform camera;
    private void Update()
    {
        camera.position = cameraPostion.position;
    }
}
