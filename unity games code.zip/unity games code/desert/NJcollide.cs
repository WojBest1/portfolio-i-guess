using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NJcollide : MonoBehaviour
{
    [SerializeField] enemyhealth eh;


    void OnTriggerEnter(Collider other)
    {

        if (other.gameObject.tag == "Enemy")
        {

            eh.takeDamage(5);


        }




    }
}
