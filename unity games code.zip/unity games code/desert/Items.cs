using UnityEngine;

public class PlayerRaycast : MonoBehaviour
{
    public LayerMask item;
    public float rayLength = 10f;
    public Canvas canvasToShow;
    void Update()
    {
        Vector3 playerPosition = transform.position;
        Vector3 playerForward = transform.forward;

     
        Ray ray = new Ray(playerPosition, playerForward);

        RaycastHit hit;

  
        if (Physics.Raycast(ray, out hit, rayLength, item))
        {

            if (canvasToShow != null)
            {

            
                canvasToShow.enabled = true;
  
         
               canvasToShow.transform.position = hit.collider.gameObject.transform.position;
            }
        }
        else
        {
     
            if (canvasToShow != null)
            {
                
                canvasToShow.enabled = false;
            }
        }
        if (Physics.Raycast(ray, out hit, rayLength, item) && Input.GetKey(KeyCode.E))
        {
    
            destroy destroyScript = hit.collider.gameObject.GetComponent<destroy>();

         
            if (destroyScript != null)
            {
                Debug.Log("Calling Destroy method on " + destroyScript.gameObject.name);
                destroyScript.Destroy();
            }
        }
    
    }
}