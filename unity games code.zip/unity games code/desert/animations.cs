using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using TMPro.EditorUtilities;
using UnityEngine;
using UnityEngine.EventSystems;

public class animations : MonoBehaviour
{
    private Animator animator;
    bool once;
    bool once1;
    float timer;
    int i = 0;
    public Transform sword;
    public Transform swords;
    public Transform hand;
    public Transform hitbox;
    [SerializeField] NinjaStar ns;
    public  float horizontalInput;
    int attack =  0;
    public float VerticalInput;
    public LayerMask whatisGround;
    [SerializeField] PlayerMovement pm;
    float timer1  =2f;
    bool starttimer;
    bool stop;
  public  bool hasword;
    public bool pressed;
   public float attackTimer = 0f;
    int currentAttackIndex =1;
    int totalAttacks = 3;
   public bool rdfsgjuig;

    void Start()
    {

        animator = GetComponent<Animator>();
    }


    void Update()
    {


        if (stop == true)
        {
            pm.moveSpeed = 0;
     
        }
    
    if(stop == false)
        {

            pm.moveSpeed = 4;
        }

     
        if (Input.GetKey(KeyCode.Space))
        {
            animator.SetBool("jump", true);


        }
        else
        {
            animator.SetBool("jump", false);

        }


      
      
            if (ns.timer ==true && ns.amountI >= 0)
            {
         

                animator.SetBool("Throwing", true);


               
            }
  


        

        if (ns.timer == false)
        {
            animator.SetBool("Throwing", false);

        }


    if (Input.GetKeyDown(KeyCode.Mouse0) && hasword )
    {
            pressed = true;
            rdfsgjuig = true;
            animator.SetInteger("attack", currentAttackIndex);
            animator.SetBool("pressed", true);

    }
   
        if (Input.GetKeyUp(KeyCode.Mouse0) && hasword)
        {
            animator.SetBool("pressed", false);

            pressed = false;
        }



        if (attackTimer >= 2)
        {

         
            animator.SetInteger("attack", currentAttackIndex);
            currentAttackIndex++;
            animator.SetBool("stop", true);
            attackTimer = 0f;
            rdfsgjuig = false; 



            if (currentAttackIndex > totalAttacks)
            {
                currentAttackIndex = 1;
                animator.SetInteger("attack", currentAttackIndex);

            }
        }

  
        if (rdfsgjuig == true)
        {
        
            attackTimer += Time.deltaTime;
        
        }
   

        if (timer1 < 2 && starttimer == true)
        {
            VerticalInput = 0;
            animator.SetBool("walking", false);
        }



        if (timer1 > 2)
        {
            animator.SetBool("walking", true);
            stop = false;
        }

        if (starttimer == true)
        {
            timer1 += Time.deltaTime;

        }
        if (attack == 3)
        {

            attack = 0;
        }


 
        if (i == 0 && timer < 3)
        {

            if (Input.GetKey(KeyCode.P))
            {
                hasword = true;
                animator.SetBool("draw", true);
                once = true;







            }

            if (once == true)
            {

                timer += Time.deltaTime;
            }
            if (timer > 1)
            {
                stop = true;
                sword.SetParent(hand);
                sword.transform.localPosition = new Vector3(-0.245000005f, 0.198200002f, -0.00359999994f);
                Vector3 targetRotation = new Vector3(17.3000011f, 74.3000031f, 8.94227753e-07f);
                Quaternion desiredRotation = Quaternion.Euler(targetRotation);
                sword.transform.localRotation = desiredRotation;

            }

            if (timer > 1.5)
            {

                stop = false;
                animator.SetBool("draw", false);
                i++;
            }
        }
        if (i == 1 && timer > 1.5)
        {
            timer = 0;
            once = false;
        }

        if (i == 1)
        {



            if (Input.GetKey(KeyCode.P))
            {

                animator.SetBool("withdraw", true);
                once1 = true;

                hasword = false;


            }

            if (once1 == true)
            {

                timer += Time.deltaTime;
            }
            if (timer > 1)
            {

                pm.moveSpeed = 0;
                sword.transform.localPosition = new Vector3(0, 0, 0);
                Vector3 targetRotation = new Vector3(0, 0, 0);
                Quaternion desiredRotation = Quaternion.Euler(targetRotation);
                sword.transform.localRotation = desiredRotation;
                sword.SetParent(swords);
            }



        

            if (timer > 1.5)
            {
                once1 = false;
                timer = 0;

                animator.SetBool("withdraw", false);
                pm.moveSpeed = 4;
                i--;
            }
        }
 
        if (pm.sprt == false)
        {

            if (VerticalInput == 1)
            {
                animator.SetBool("walking", true);
            }
            if (VerticalInput == -1)
            {
                animator.SetBool("walkback", true);

            }
        }
        if (horizontalInput == 1)
        {
            animator.SetBool("walkright", true);

        }
        if (horizontalInput == -1)
        {
            animator.SetBool("walkleft", true);

        }

        if (pm.sprt == true)
        {
            animator.SetBool("walkback", false);
            animator.SetBool("walking", false);
            animator.SetBool("spriting", true);

        }

        horizontalInput = Input.GetAxisRaw("Horizontal");
        VerticalInput = Input.GetAxisRaw("Vertical");

        if (horizontalInput == 0 && VerticalInput == 0)
        {
            animator.SetBool("spriting", false);
            animator.SetBool("walking", false);
            animator.SetBool("walkback", false);
            animator.SetBool("walkleft", false);
            animator.SetBool("walkright", false);

        }

        if (Input.GetKeyDown(KeyCode.X))
        {

      
            animator.SetBool("crouch", true);
            hitbox.transform.localScale = new Vector3(hitbox.transform.localScale.x, 0.7f, hitbox.transform.localScale.z);
      
            hitbox.transform.localPosition = new Vector3(0, 0.7f, 0);



        }
        if (VerticalInput == 1 && animator.GetBool("crouch") == true)
        {
            animator.SetBool("crouchf", true);



            Debug.Log(VerticalInput);
        }

        else if (VerticalInput == -1 && animator.GetBool("crouch") == true)
        {


            Debug.Log(VerticalInput);
        }
        if (horizontalInput == 1)
        {
            animator.SetBool("crouchright", true);
         
        }
        if (horizontalInput == -1)
        {
            animator.SetBool("crouchleft", true);

        }
        if (horizontalInput == 0)


        {
            animator.SetBool("crouchright",false);
            animator.SetBool("crouchleft",false);
        }

        if (VerticalInput == 0)
        {
            animator.SetBool("crouchb", false);
            animator.SetBool("crouchf", false);

        }

        if (Input.GetKeyUp(KeyCode.X))
        {
            animator.SetBool("crouch", false);
            hitbox.transform.localScale = new Vector3(hitbox.transform.localScale.x, 1f, hitbox.transform.localScale.z);

            hitbox.transform.localPosition = new Vector3(0, 0.957f, 0);
        }
    }
}
