using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    [SerializeField] GameObject[] waypoints; 
    int  CurrentWaypointIndex = 0;

    [SerializeField]  float speed = 1.0f;

    void Update()
    {
        
        if (Vector3.Distance(transform.position, waypoints[CurrentWaypointIndex].transform.position) < .1f)
        {
            CurrentWaypointIndex++;
            if (CurrentWaypointIndex >= waypoints.Length)
            {
                CurrentWaypointIndex = 0;
            }
        }

        
        transform.position = Vector3.MoveTowards(transform.position, waypoints[CurrentWaypointIndex].transform.position, speed * Time.deltaTime);      
    }
}
