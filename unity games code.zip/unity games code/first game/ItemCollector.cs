using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;



public class ItemCollector : MonoBehaviour
{
    int coins = 0;
    [SerializeField] private TextMeshProUGUI coinsText;

    [SerializeField] AudioSource collectsound;



    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Coin"))
        {
            Destroy(other.gameObject);           
            coins++;
            coinsText.text = "Coins: " + coins;
            collectsound.Play();
        }

        
    }

}