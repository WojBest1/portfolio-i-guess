using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.U2D;

public class Camera1 : MonoBehaviour
{
    public Transform Cam;
    public Transform player;
    public float xRotation;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    void Update()
    {
        float mouseX = Input.GetAxis("Mouse X");
        float mouseY= Input.GetAxis("Mouse Y");

     
        xRotation -= mouseY;

        xRotation = Mathf.Clamp(xRotation, -90f, 90f);


        Quaternion currentRotation = Cam.transform.rotation;
        Quaternion newRotation = Quaternion.Euler(xRotation + -mouseY, currentRotation.eulerAngles.y + mouseX, currentRotation.eulerAngles.z);
        Cam.transform.rotation = newRotation;


        player.Rotate(Vector3.up * mouseX);
 
    }
}
