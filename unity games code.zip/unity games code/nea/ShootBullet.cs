using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShootBullet : MonoBehaviour
{
    public Pistol pistol;
    public GameObject bulletPrefab; 
    public Transform shootPlace;
    public float bulletSpeed = 100f;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0) && pistol.canShoot == true)
        {
            var bullet = Instantiate(bulletPrefab,shootPlace.position,shootPlace.rotation);


      
            bullet.GetComponent<Rigidbody>().velocity = shootPlace.forward * bulletSpeed;
    
        }

    }
}

