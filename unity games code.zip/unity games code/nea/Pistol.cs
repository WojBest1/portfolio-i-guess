using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class Pistol : MonoBehaviour
{
  
    public Transform arms;
    public Camera cam;
    float zoomSpeed;
    Vector3 initialArmsPosition;
    public Animator animator;
    public GameObject MuzzleFlash;
    float fireRate = 0.5f;
    bool AbleShoot = true;
    const float constmag = 12;
    float currentmag = 12;
    float Reserve = 128;
   public bool canShoot;
    Vector3 targetArmsPosition;
    public Text txt;

    void Start()
    {
        initialArmsPosition = arms.localPosition;
        targetArmsPosition = initialArmsPosition;

    }

    void Update()
    {







        if (Input.GetKey(KeyCode.Mouse1) && animator.GetBool("Reload") == false)
        {
            animator.SetBool("isShooting", true);

            targetArmsPosition = new Vector3(0.48f, -0.21f, 0.87f);
            cam.fieldOfView = 24;
            zoomSpeed = 0.03f;
         
        }
        else if (Input.GetKeyUp(KeyCode.Mouse1) && animator.GetBool("Reload") == false)
        {
            animator.SetBool("isShooting", false);
            targetArmsPosition = initialArmsPosition;
            zoomSpeed = 0.5f;
            cam.fieldOfView = 90;
        }





        arms.localPosition = Vector3.Lerp(arms.localPosition, targetArmsPosition, zoomSpeed);
    


        if (Input.GetKeyDown(KeyCode.Mouse0) && animator.GetBool("isShooting") == false && AbleShoot == true && Reserve > 0 && currentmag > 0 && animator.GetBool("Reload") == false)
        {
            currentmag--;
 
            MuzzleFlash.SetActive(true);        
            StartCoroutine(MF());
            animator.SetBool("shoot", true);
            AbleShoot = false;
            StartCoroutine(FR());
        }
        if (Input.GetKeyDown(KeyCode.Mouse0) && animator.GetBool("isShooting") == true && AbleShoot == true && Reserve > 0 && currentmag > 0 && animator.GetBool("Reload") == false)
        {
            currentmag--;
            
            MuzzleFlash.SetActive(true);
            StartCoroutine(MF());
            animator.SetBool("AimShoot", true);
            AbleShoot = false;
            StartCoroutine(FR());

        }

        if (Input.GetKeyUp(KeyCode.Mouse0) && animator.GetBool("isShooting") == false && animator.GetBool("Reload") == false)
        {
            animator.SetBool("shoot", false);
      
        }
        if (Input.GetKeyUp(KeyCode.Mouse0) && animator.GetBool("isShooting") == true && animator.GetBool("Reload") == false)
        {
            animator.SetBool("AimShoot", false);


        }
        if (Input.GetKeyUp(KeyCode.R) && Reserve > 0 && currentmag >= 0  && currentmag != 12&&animator.GetBool("Reload") == false)
        {
            animator.SetBool("Reload", true);
          
            StartCoroutine(Reload());
      
        }
        if (Reserve > 0 && currentmag > 0 && AbleShoot == true && animator.GetBool("Reload") == false)
        {
            canShoot = true;
        }
        else
        {
            canShoot = false;
        }
        txt.text = currentmag.ToString() + "/" + Reserve.ToString(); 
    }


    IEnumerator Reload()
    {

        yield return new WaitForSeconds(1.2f);
        float lessbullets = constmag - currentmag;
        Reserve -= lessbullets;
        currentmag = 12;
        animator.SetBool("Reload", false);

    }

    IEnumerator MF()
    {

        yield return new WaitForSeconds(0.1f);
        MuzzleFlash.SetActive(false);
    }
    IEnumerator FR()
    {



        yield return new WaitForSeconds(fireRate);
        AbleShoot = true;



    }
    }

