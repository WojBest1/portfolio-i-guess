using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{

    public Transform Player;
    public Transform cam;
    public KeyCode Jump = KeyCode.Space;
    public KeyCode Sprint = KeyCode.LeftShift;
    public KeyCode forwards = KeyCode.W;
    public KeyCode backwards = KeyCode.S;
    public KeyCode left = KeyCode.A;
    public KeyCode right = KeyCode.D;
    float movespeed = 7f;
    float x;
    float z;
    Vector3 movementDirection;

    void Start()
    {

    }


    void Update()
    {



        if (Input.GetKey(forwards)|| Input.GetKey(left)||Input.GetKey(right) || Input.GetKey(backwards))
        {
            x = Input.GetAxis("Horizontal");
            z = Input.GetAxis("Vertical");


            sprint();

            movementDirection = (transform.forward * z + transform.right * x).normalized;

            transform.Translate(movementDirection * Time.deltaTime * movespeed, Space.Self);
        }


    }
    void sprint()
    {
        if (Input.GetKeyDown(Sprint))
        {
            movespeed = 10f;

        }
        if (Input.GetKeyUp(Sprint))
        {
            movespeed = 7f;

        }



    }


}